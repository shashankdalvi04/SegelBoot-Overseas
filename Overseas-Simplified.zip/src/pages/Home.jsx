function Home() {
  return (
    <section className="text-center py-20">
      <h2 className="text-3xl font-bold mb-4">Welcome to Overseas</h2>
      <p className="text-gray-700 max-w-2xl mx-auto">
        We help students pursue their education abroad with the right guidance
        and opportunities.
      </p>
    </section>
  );
}

export default Home;
