function Services() {
  return (
    <section className="py-20 text-center">
      <h2 className="text-3xl font-bold mb-4">Our Services</h2>
      <ul className="space-y-4">
        <li>🎓 Study Abroad Consulting</li>
        <li>📄 Application Assistance</li>
        <li>✈️ Visa Guidance</li>
      </ul>
    </section>
  );
}

export default Services;
