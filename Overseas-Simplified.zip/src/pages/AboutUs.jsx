function AboutUs() {
  return (
    <section className="py-20 text-center">
      <h2 className="text-3xl font-bold mb-4">About Us</h2>
      <p className="text-gray-700 max-w-2xl mx-auto">
        We are a team dedicated to guiding students to achieve their dreams of
        studying abroad. Our mission is to provide reliable support from
        counseling to settling in a new country.
      </p>
    </section>
  );
}

export default AboutUs;
